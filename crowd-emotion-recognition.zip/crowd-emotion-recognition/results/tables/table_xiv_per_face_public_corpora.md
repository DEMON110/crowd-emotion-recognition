| Corpus | Composition | Top-1 (%) | Macro-F1 (%) | Balanced acc. (%) | MCC |
|---|---|---|---|---|---|
| FER-2013 | 10,000 in-the-wild faces, balanced over 4 classes | 63.7 | 63.7 | 63.7 | 0.516 |
| JAFFE | 122 posed faces over 4 classes | 95.9 | 95.9 | 95.9 | 0.946 |
