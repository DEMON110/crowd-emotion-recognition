| System | Runtime (ms/img) | Energy (J/img) | Images per kWh | kWh per 1M images/day |
|---|---|---|---|---|
| Proposed pipeline | 14 | 1.12 | 3214285 | 0.31 |
| CNN-4 | 46 | 3.68 | 978260 | 1.02 |
| ResNet-50 | 68 | 5.44 | 661764 | 1.51 |
| VGG-16 | 218 | 17.44 | 206422 | 4.84 |
