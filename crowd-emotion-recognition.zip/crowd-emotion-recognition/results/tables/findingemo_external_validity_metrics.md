| Metric | Value | Chance level | Note |
|---|---|---|---|
| Top-1 scene agreement | 29.6% [26.6, 32.9] | 25% | near chance - construct mismatch |
| Macro-F1 | 26.7% | 25% |  |
| MCC | 0.065 | 0.0 |  |
| Binary valence agreement | 56.9% | 50% | Happy/Surprise=pos, Sad/Anger=neg |
| Scene-valence Spearman rho | 0.183 | 0.0 | p < 1e-6 |
