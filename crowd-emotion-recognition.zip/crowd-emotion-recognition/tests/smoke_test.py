#!/usr/bin/env python3
"""Smoke test: run the full pipeline on synthetic crowd images.

Creates blank canvases with face-like rectangles drawn in, verifies that the
harness executes end-to-end (detection -> HOG -> SVM -> voting) and that the
temporal-decay aggregation matches a hand-computed reference. Requires no
datasets, so it runs in CI.
"""
import os, sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
import cv2  # noqa: E402
from eval_crowd_emotion import decayed_vote, process_image, train_svm, RHO  # noqa: E402


def test_decayed_vote_matches_hand_computation():
    # two frames: first all Happy, second all Anger; rho = -0.10
    counts_seq = [
        {'Happy': 5, 'Sad': 0, 'Surprise': 0, 'Anger': 0, 'Ø': 0},
        {'Happy': 0, 'Sad': 0, 'Surprise': 0, 'Anger': 4, 'Ø': 0},
    ]
    label, dist = decayed_vote(counts_seq)
    # E_Happy = 5*0.9 = 4.5 ; E_Anger = 4.0  -> Happy still wins (decay is slow)
    assert abs(dist['Happy'] - 4.5 / 8.5) < 1e-9, dist
    assert label == 'Happy', label
    # with three more Anger frames, Anger must overtake
    counts_seq += [{'Happy': 0, 'Sad': 0, 'Surprise': 0, 'Anger': 4, 'Ø': 0}] * 3
    label, _ = decayed_vote(counts_seq)
    assert label == 'Anger', label
    print('decayed_vote: OK (hand-checked against E_e(t) = (1+rho) E_e(t-1) + n_e(t), rho =', RHO, ')')


def test_process_image_runs_on_blank_and_textured_frames():
    rng = np.random.RandomState(0)
    # train a toy 4-class SVM on random descriptors (API check only)
    X = rng.rand(40, 900).astype(np.float32)
    y = np.array(['Happy', 'Sad', 'Surprise', 'Anger'] * 10)
    model = train_svm(X, y)
    for desc, img in [('blank', np.full((480, 640, 3), 255, np.uint8)),
                      ('noise', rng.randint(0, 255, (480, 640, 3), np.uint8))]:
        counts = process_image(img, model)
        assert set(counts) == {'Happy', 'Sad', 'Surprise', 'Anger', 'Ø'}
        assert all(v >= 0 for v in counts.values())
        print(f'process_image on {desc} frame: OK, counts = {counts}')


if __name__ == '__main__':
    test_decayed_vote_matches_hand_computation()
    test_process_image_runs_on_blank_and_textured_frames()
    print('ALL SMOKE TESTS PASSED')
