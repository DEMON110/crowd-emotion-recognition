#!/usr/bin/env python3
"""
eval_crowd_emotion.py — Reference evaluation harness for:

  "Crowd-Level Emotion Recognition from Still-Image Sequences via a
   Cascaded Viola–Jones Detector, HOG–Quadratic-SVM Classification,
   and Temporally Decayed Evidence Voting"

Implements the pipeline exactly as specified in Table II and Algorithm 1:

  Stage 1 (per image):  Viola–Jones cascade (scaleFactor 1.1, minNeighbors 3)
                        -> FP suppression (average-width threshold,
                           upper-body consistency)
                        -> HOG (64x64 win, 16x16 cells, 2x2 blocks, stride 8,
                           9 unsigned bins, L2-Hys)
                        -> quadratic SVM (c=1, C=1, one-vs-rest)
                        -> non-classifiable state (Ø) below confidence tau
  Stage 2 (sequence):   temporal decay of evidence, E_e(t) = (1+rho) E_e(t-1)
                        + n_e(t), rho = -0.10, majority voting.

Modes:
  train-jaffe   : 10-fold CV of the per-face stage on JAFFE (public).
  infer-dir     : run Stage-1 inference on a directory of crowd images and
                  score against whole-scene labels (FindingEmo protocol).

Dependencies: opencv-python, scikit-learn, numpy.
"""
import argparse, json, os, sys, time, glob, random
import numpy as np
import cv2

# ---------------------------------------------------------------- constants
EMOTIONS = ['Happy', 'Sad', 'Surprise', 'Anger']   # + Ø (non-classifiable)
RHO = -0.10                                        # temporal decay rate
TAU = 0.0                                          # Ø confidence threshold
CASCADE_FACE = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
CASCADE_UPPER = cv2.data.haarcascades + 'haarcascade_upperbody.xml'

hog = cv2.HOGDescriptor((64, 64), (32, 32), (8, 8), (16, 16), 9)
# winSize 64x64, blockSize 32x32 (2x2 cells), blockStride 8x8, cellSize 16x16,
# nbins 9, unsigned gradients (0-180), L2-Hys block normalisation (defaults)

# ---------------------------------------------------------------- stage 1
def detect_faces(img_gray, scale_factor=1.1, min_neighbors=3):
    """Viola–Jones cascade + the two FP-suppression strategies of Sec. III-B."""
    face_cascade = cv2.CascadeClassifier(CASCADE_FACE)
    faces = face_cascade.detectMultiScale(img_gray, scaleFactor=scale_factor,
                                          minNeighbors=min_neighbors)
    faces = [tuple(map(int, f)) for f in faces]
    if not faces:
        return []
    # strategy 1: average-width threshold
    mean_w = np.mean([w for (_, _, w, _) in faces])
    faces = [f for f in faces if f[2] > mean_w]
    if not faces:
        return []
    # strategy 2: upper-body consistency
    kept = faces
    if os.path.exists(CASCADE_UPPER):
        upper_cascade = cv2.CascadeClassifier(CASCADE_UPPER)
        uppers = upper_cascade.detectMultiScale(img_gray, scaleFactor=scale_factor,
                                                minNeighbors=min_neighbors)
        uppers = [tuple(map(int, u)) for u in uppers]
        if uppers:
            mean_u = np.mean([w for (_, _, w, _) in uppers])
            uppers = [u for u in uppers if u[2] > mean_u]
            if uppers:
                def supported(f):
                    fx, fy, fw, fh = f
                    return any(not (fx + fw < ux or ux + uw < fx or
                                    fy + fh < uy or uy + uh < fy)
                               for (ux, uy, uw, uh) in uppers)
                kept = [f for f in faces if supported(f)] or faces
    return kept

def hog_of_patch(img_gray, box):
    x, y, w, h = box
    patch = img_gray[max(y, 0):y + h, max(x, 0):x + w]
    patch = cv2.resize(patch, (64, 64), interpolation=cv2.INTER_LINEAR)
    return hog.compute(patch).ravel()

def svm_predict(model, descr):
    """Return (label, max OvR decision value); Ø below confidence TAU."""
    dv = model.decision_function([descr])[0]
    k = int(np.argmax(dv))
    if dv[k] < TAU:
        return 'Ø', float(dv[k])
    return model.classes_[k], float(dv[k])

def process_image(img_bgr, model):
    """Algorithm 1, Stage 1: returns counts n_e over EMOTIONS + Ø.

    Input normalisation: frames are capped at 1280 px on the long side
    (memory-safe reference implementation; detection parameters unchanged).
    """
    h, w = img_bgr.shape[:2]
    s = 1280.0 / max(h, w)
    if s < 1.0:
        img_bgr = cv2.resize(img_bgr, (int(w * s), int(h * s)),
                             interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    counts = {e: 0 for e in EMOTIONS + ['Ø']}
    for box in detect_faces(gray):
        label, _ = svm_predict(model, hog_of_patch(gray, box))
        counts[label] += 1
    return counts

# ---------------------------------------------------------------- stage 2
def decayed_vote(counts_seq, rho=RHO):
    """Algorithm 1, Stage 2: E_e(t) = (1+rho) E_e(t-1) + n_e(t)."""
    E = {e: 0.0 for e in EMOTIONS + ['Ø']}
    for counts in counts_seq:
        for e in E:
            E[e] = (1.0 + rho) * E[e] + counts[e]
    label = max(EMOTIONS, key=lambda e: E[e])   # Ø can never win a scene label
    total = sum(E.values()) or 1.0
    return label, {e: E[e] / total for e in E}

# ---------------------------------------------------------------- SVM
def train_svm(X, y):
    from sklearn.svm import SVC
    model = SVC(kernel='poly', degree=2, coef0=1.0, C=1.0,
                decision_function_shape='ovr')
    model.fit(X, y)
    return model

# ---------------------------------------------------------------- JAFFE
JAFFE_MAP = {'AN': 'Anger', 'HA': 'Happy', 'SA': 'Sad', 'SU': 'Surprise'}

def load_jaffe(jaffe_dir):
    X, y, names = [], [], []
    for f in sorted(glob.glob(os.path.join(jaffe_dir, '*.tiff'))):
        code = os.path.basename(f).split('.')[1][:2]
        if code not in JAFFE_MAP:
            continue
        img = cv2.imread(f, cv2.IMREAD_GRAYSCALE)
        boxes = detect_faces(img)
        x, yb, w, h = boxes[0] if boxes else (16, 16, 224, 224)
        X.append(hog_of_patch(img, (x, yb, w, h)))
        y.append(JAFFE_MAP[code])
        names.append(os.path.basename(f))
    return np.array(X), np.array(y), names

def cmd_train_jaffe(args):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import (accuracy_score, f1_score, balanced_accuracy_score,
                                 matthews_corrcoef, confusion_matrix)
    X, y, names = load_jaffe(args.jaffe)
    print(f'JAFFE per-face corpus: {len(X)} faces, classes: '
          f'{dict(zip(*np.unique(y, return_counts=True)))}')
    skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
    preds = np.empty_like(y)
    for tr, te in skf.split(X, y):
        model = train_svm(X[tr], y[tr])
        preds[te] = model.predict(X[te])
    acc = accuracy_score(y, preds)
    mf1 = f1_score(y, preds, average='macro')
    ba = balanced_accuracy_score(y, preds)
    mcc = matthews_corrcoef(y, preds)
    print(f'10-fold CV  Acc={acc:.4f}  MacroF1={mf1:.4f}  BA={ba:.4f}  MCC={mcc:.4f}')
    print('confusion matrix (rows=true, cols=' + str(EMOTIONS) + '):')
    print(confusion_matrix(y, preds, labels=EMOTIONS))
    model = train_svm(X, y)   # final model: all JAFFE data
    out = {'classes': list(model.classes_),
           'n_support': model.n_support_.tolist(),
           'dual_coef': model.dual_coef_.tolist(),
           'intercept': model.intercept_.tolist(),
           'support_vectors': model.support_vectors_.tolist(),
           'probA': model._probA.tolist(), 'probB': model._probB.tolist()}
    import joblib
    joblib.dump(model, args.model_out)
    print('model written to', args.model_out)


FER2013_MAP = {0: 'Anger', 3: 'Happy', 4: 'Sad', 5: 'Surprise'}
# FER-2013 labels: 0 Angry, 1 Disgust, 2 Fear, 3 Happy, 4 Sad, 5 Surprise, 6 Neutral

def load_fer2013(parquet_path, per_class=2500, seed=42):
    """Balanced 4-class subsample of the FER-2013 train split."""
    import pandas as pd
    df = pd.read_parquet(parquet_path)
    rng = np.random.RandomState(seed)
    X, y = [], []
    for code, name in FER2013_MAP.items():
        sub = df[df['label'] == code]
        sel = rng.choice(len(sub), per_class, replace=False)
        for b in sub.iloc[sel]['image'].values:
            a = cv2.imdecode(np.frombuffer(b['bytes'], np.uint8),
                             cv2.IMREAD_GRAYSCALE)
            a = cv2.resize(a, (64, 64), interpolation=cv2.INTER_LINEAR)
            X.append(hog.compute(a).ravel())
            y.append(name)
    return np.array(X), np.array(y)

def cmd_train_fer(args):
    """10-fold CV on FER-2013 (substitute for licence-restricted FER+)."""
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import (accuracy_score, f1_score, balanced_accuracy_score,
                                 matthews_corrcoef, confusion_matrix)
    X, y = load_fer2013(args.fer2013)
    print(f'FER-2013 per-face corpus: {len(X)} faces, classes: '
          f'{dict(zip(*np.unique(y, return_counts=True)))}')
    skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
    preds = np.empty_like(y)
    for tr, te in skf.split(X, y):
        model = train_svm(X[tr], y[tr])
        preds[te] = model.predict(X[te])
    print(f'10-fold CV  Acc={accuracy_score(y, preds):.4f}  '
          f'MacroF1={f1_score(y, preds, average="macro"):.4f}  '
          f'BA={balanced_accuracy_score(y, preds):.4f}  '
          f'MCC={matthews_corrcoef(y, preds):.4f}')
    print('confusion matrix (rows=true, cols=' + str(EMOTIONS) + '):')
    print(confusion_matrix(y, preds, labels=EMOTIONS))
    model = train_svm(X, y)
    import joblib
    joblib.dump(model, args.model_out)
    print('model written to', args.model_out)

def load_model(path):
    import joblib
    return joblib.load(path)

# ------------------------------------------------------------- FindingEmo
def cmd_infer_dir(args):
    from sklearn.metrics import (accuracy_score, f1_score, balanced_accuracy_score,
                                 matthews_corrcoef, confusion_matrix)
    model = load_model(args.model)
    manifest = json.load(open(args.manifest))
    rows, t0 = [], time.time()
    for item in manifest:
        img = cv2.imread(item['file'])
        if img is None:
            continue
        t1 = time.time()
        counts = process_image(img, model)
        dt = time.time() - t1
        n = sum(counts.values())
        label, dist = decayed_vote([counts])   # single frame = special case
        rows.append({'file': item['file'], 'true': item['label'],
                     'pred': label, 'n_faces': n, 'counts': counts, 'ms': dt * 1000})
        del img
        if len(rows) % 25 == 0:
            import gc; gc.collect()
            print(f'{len(rows)}/{len(manifest)}', flush=True)
    y_true = [r['true'] for r in rows]
    y_pred = [r['pred'] for r in rows]
    n = len(rows)
    acc = accuracy_score(y_true, y_pred)
    mf1 = f1_score(y_true, y_pred, average='macro')
    ba = balanced_accuracy_score(y_true, y_pred)
    mcc = matthews_corrcoef(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred, labels=EMOTIONS)
    ms = [r['ms'] for r in rows]
    res = {'n_scenes': n, 'top1_agreement': acc, 'macro_f1': mf1,
           'balanced_accuracy': ba, 'mcc': mcc,
           'confusion': {'labels': EMOTIONS, 'matrix': cm.tolist()},
           'runtime_ms_per_image': {'mean': float(np.mean(ms)),
                                    'std': float(np.std(ms))},
           'faces': {'total': int(sum(r['n_faces'] for r in rows)),
                     'zero_face_scenes': int(sum(1 for r in rows if r['n_faces'] == 0))},
           'per_row': rows}
    json.dump(res, open(args.out, 'w'), indent=1)
    print(json.dumps({k: v for k, v in res.items() if k != 'per_row'}, indent=1))

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('train-jaffe')
    p.add_argument('--jaffe', required=True)
    p.add_argument('--model-out', required=True)
    p = sub.add_parser('train-fer')
    p.add_argument('--fer2013', required=True,
                   help='FER-2013 train parquet (label + image.bytes)')
    p.add_argument('--model-out', required=True)
    p = sub.add_parser('infer-dir')
    p.add_argument('--model', required=True)
    p.add_argument('--manifest', required=True)
    p.add_argument('--out', required=True)
    args = ap.parse_args()
    {'train-jaffe': cmd_train_jaffe, 'train-fer': cmd_train_fer,
     'infer-dir': cmd_infer_dir}[args.cmd](args)

if __name__ == '__main__':
    main()
