# Data — how to obtain every dataset

**No dataset is redistributed in this repository.** Each source is governed by
its own licence; the script `download_data.py` fetches them from their official
or publicly documented locations. By running it you accept each dataset's
terms of use.

| Dataset | Used for | Licence / access | Obtained via |
|---|---|---|---|
| **JAFFE** [1] | Table XIV — per-face external validation (posed) | Free for **non-commercial research only**; **redistribution (incl. GitHub/Kaggle) is explicitly forbidden** | `python data/download_data.py jaffe` (Zenodo record 14974867) |
| **FER-2013** [2] | Table XIV — per-face external validation (in-the-wild) | Public competition corpus; FER+ labels are licence-restricted, which is why the replication uses FER-2013 (stated in §IV-H) | `python data/download_data.py fer2013` |
| **FindingEmo** [3] | External-validity pilot (whole-scene labels; **not** part of the paper's headline results — see `notebooks/03`) | CC BY-NC-SA 4.0; annotations + image URLs | `python data/download_data.py findingemo` (clones the official GitLab repo, then downloads the subset referenced by URLs) |
| **GAF 3.0 / VGAF** [4,5] | Pre-registered crowd-level protocol (§IV-H), pending licence | Free for research **upon request to the EmotiW organisers** | e-mail request; see §IV-H of the manuscript |
| **In-house datasets A/B** | §IV-A–IV-E headline results | Institutional policy: group-level annotations shareable on reasonable request; imagery contains identifiable persons | contact the corresponding author |

## Layout after downloading

```
data/
├── raw/
│   ├── jaffe/            # 213 .tiff files (256×256, 8-bit gray)
│   ├── fer2013_train.parquet
│   └── findingemo/       # cloned repo + downloaded subset images
└── processed/            # manifests / label maps written by the scripts
```

## References

1. Lyons, M., Akamatsu, S., Kamachi, M., Gyoba, J. "Coding facial expressions
   with Gabor wavelets." *Proc. 3rd IEEE Int. Conf. on Automatic Face and
   Gesture Recognition (FG)*, pp. 200–205, 1998.
2. Goodfellow, I. J. et al. "Challenges in representation learning: A report
   on three machine learning contests." *Neural Networks*, 64:59–63, 2015.
3. Van Hove, D. et al. "FindingEmo: An image dataset for emotion recognition
   in the wild." arXiv:2402.01355, 2024.
4. Dhall, A. et al. "From individual to group-level emotion recognition:
   EmotiW 5.0." *Proc. ICMI*, 2017.
5. Sharma, G., Ghosh, S., Dhall, A. "Automatic group level affect and cohesion
   prediction in videos." *Proc. ACIIW*, pp. 161–167, 2019.
