#!/usr/bin/env python3
"""Download the public datasets used by this repository.

Usage:
    python data/download_data.py jaffe        # JAFFE (Zenodo 14974867)
    python data/download_data.py fer2013      # FER-2013 train split (parquet)
    python data/download_data.py findingemo   # FindingEmo annotations + subset

Nothing is redistributed here — every file comes from its official or
publicly documented location. Check data/README.md for licences; JAFFE in
particular forbids redistribution and is limited to non-commercial research.
"""
import argparse, io, json, os, subprocess, sys, urllib.request, zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, 'raw')
PROC = os.path.join(ROOT, 'processed')

JAFFE_URL = 'https://zenodo.org/records/14974867/files/jaffe.zip?download=1'
FER_URL = ('https://hf-mirror.com/datasets/AutumnQiu/fer2013/resolve/main/'
           'data/train-00000-of-00001.parquet')
FE_REPO = 'https://gitlab.com/EAVISE/lme/findingemo.git'


def fetch(url, dest, expected_min=1_000_000, tries=30):
    """Resumable download (Zenodo in particular can be slow)."""
    for i in range(tries):
        rc = subprocess.run(['curl', '-sL', '-C', '-', '--max-time', '300',
                             '-o', dest, url]).returncode
        if rc == 0 and os.path.getsize(dest) >= expected_min:
            return dest
    raise RuntimeError(f'download incomplete: {url} -> {dest}')


def jaffe():
    os.makedirs(RAW, exist_ok=True)
    zpath = os.path.join(RAW, 'jaffe.zip')
    fetch(JAFFE_URL, zpath, expected_min=12_000_000)
    out = os.path.join(RAW, 'jaffe')
    with zipfile.ZipFile(zpath) as z:
        z.extractall(out)
    n = sum(1 for f in os.walk(out) for f in f[2] if f.lower().endswith('.tiff'))
    print(f'JAFFE: {n} tiff images under {out}')
    print('Reminder: JAFFE is for non-commercial research only; do NOT '
          'redistribute (see data/README.md).')


def fer2013():
    os.makedirs(RAW, exist_ok=True)
    dest = os.path.join(RAW, 'fer2013_train.parquet')
    fetch(FER_URL, dest, expected_min=100_000_000, tries=5)
    print(f'FER-2013 train split: {dest}')


def findingemo(per_class=200, out_dir=None):
    """Clone the FindingEmo repo and download a balanced 4-class subset.

    Scene labels are derived by majority vote over the per-image Plutchik
    annotations, mapped to the four pipeline classes:
        Joy/Ecstasy/Serenity -> Happy;  Sadness/Grief/Pensiveness -> Sad;
        Surprise/Amazement/Distraction -> Surprise;  Anger/Rage/Annoyance -> Anger.
    """
    import pandas as pd
    out_dir = out_dir or os.path.join(RAW, 'findingemo')
    os.makedirs(out_dir, exist_ok=True)
    repo = os.path.join(out_dir, 'findingemo')
    if not os.path.isdir(repo):
        subprocess.run(['git', 'clone', '--depth', '1', FE_REPO, repo],
                       check=True)
    ann = pd.read_csv(os.path.join(repo, 'data', 'annotations_single.ann'))
    urls = json.load(open(os.path.join(repo, 'data',
                                       'dataset_urls_exploded.json')))
    by_path = {}
    for e in urls:
        by_path.setdefault(e['rel_path'], []).append(e['url'])

    MAP = {'Joy': 'Happy', 'Ecstasy': 'Happy', 'Serenity': 'Happy',
           'Sadness': 'Sad', 'Grief': 'Sad', 'Pensiveness': 'Sad',
           'Surprise': 'Surprise', 'Amazement': 'Surprise',
           'Distraction': 'Surprise',
           'Anger': 'Anger', 'Rage': 'Anger', 'Annoyance': 'Anger'}
    votes = {}
    for _, row in ann.iterrows():
        lab = MAP.get(row['emotion'])
        if lab:
            votes.setdefault(row['image_path'], []).append(lab)
    scene = {}
    for path, vs in votes.items():
        scene[path] = max(set(vs), key=vs.count)

    img_dir = os.path.join(out_dir, 'images')
    os.makedirs(img_dir, exist_ok=True)
    manifest, got = [], {c: 0 for c in ('Happy', 'Sad', 'Surprise', 'Anger')}
    ua = {'User-Agent': 'crowd-emotion-replication/1.0 (research use)'}
    import cv2  # validation only
    import numpy as np
    for path, label in sorted(scene.items()):
        if got[label] >= per_class:
            continue
        ok = False
        for url in by_path.get(path, [])[:4]:
            dest = os.path.join(img_dir, path.replace('/', '__'))
            try:
                req = urllib.request.Request(url, headers=ua)
                blob = urllib.request.urlopen(req, timeout=20).read()
                if len(blob) < 9000:
                    continue
                arr = cv2.imdecode(np.frombuffer(blob, np.uint8),
                                   cv2.IMREAD_COLOR)
                if arr is None or min(arr.shape[:2]) < 150:
                    continue
                cv2.imwrite(dest, arr)
                ok = True
                break
            except Exception:
                continue
        if ok:
            got[label] += 1
            manifest.append({'rel_path': path, 'label': label, 'file': dest})
    os.makedirs(PROC, exist_ok=True)
    mpath = os.path.join(PROC, 'findingemo_manifest.json')
    json.dump(manifest, open(mpath, 'w'), indent=1)
    print(f'FindingEmo subset: {got}; manifest -> {mpath}')


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('dataset', choices=['jaffe', 'fer2013', 'findingemo'])
    ap.add_argument('--per-class', type=int, default=200)
    a = ap.parse_args()
    {'jaffe': jaffe, 'fer2013': fer2013,
     'findingemo': lambda: findingemo(a.per_class)}[a.dataset]()
